/**
* 確認テスト0703
* 
* 日付：
* 名前：
*
* 問題 
* 下記の仕様のプログラムを作成してください
*
* arrayを小さい順に並び替えて表示する
*
*
* 出力される文言は以下の通り。
* -62
* -34
* -7
* 2
* 12
* 27
* 30
* 54
* 75
* 91
*/
package jp.co.FStest07;
public class FStest0703 {
	
	
    public static void main(String[] args) {
		int[] array = {12,54,2,-7,30,75,-34,91,27,-62};

    }
}