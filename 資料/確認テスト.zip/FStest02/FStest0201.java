/**
* 確認テスト02
* 
* 日付：
* 名前：
*
* 問題 
* for文を使用して、1から10まで表示するプログラムを作成してください
* 出力される文言は以下の通り。
* 1
* 2
* 3
* 4
* 5
* 6
* 7
* 8
* 9
* 10
*/
package jp.co.FStest02;
public class FStest0201 {
	
	
    public static void main(String[] args) {
    	//↓↓↓↓ここに記述↓↓↓↓
    	
    	//↑↑↑↑ここに記述↑↑↑↑
    	
    }
}