/**
* 確認テスト0202
* 
* 日付：
* 名前：
*
* 問題 
* for文を使用して、10から1まで表示するプログラムを作成してください
* 出力される文言は以下の通り。
* 10
* 9
* 8
* 7
* 6
* 5
* 4
* 3
* 2
* 1
*/
package jp.co.FStest02;
public class FStest0202 {
	
	
    public static void main(String[] args) {
    	//↓↓↓↓ここに記述↓↓↓↓
    	
    	//↑↑↑↑ここに記述↑↑↑↑
    	
    }
}